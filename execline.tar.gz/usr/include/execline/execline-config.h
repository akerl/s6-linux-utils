/* ISC license. */

#ifndef EXECLINE_CONFIG_H
#define EXECLINE_CONFIG_H

#define EXECLINE_VERSION "1.3.1.1"

#define EXECLINE_BINPREFIX ""
#define EXECLINE_EXTBINPREFIX ""


#endif
